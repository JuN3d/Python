# Contoh Pengulangan for sederhana

angka = [1,2,3,4,5]
for x in angka:
    print(x)

# Contoh Pengulangan for

buah = ["nanas","apel", "jeruk"]
for makanan in buah:
    print("Saya suka makan",makanan)