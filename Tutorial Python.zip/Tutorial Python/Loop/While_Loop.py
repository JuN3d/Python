# Contoh Penggunaan While Loop
# Catatan: Penentuan ruang lingkup di Python bisa menggunakan tab alih-alih menggunakan tanda kurung

count = 0

while(count < 9):
    print("The count is : ", count)
    count = count + 1
print("Good Bye!")