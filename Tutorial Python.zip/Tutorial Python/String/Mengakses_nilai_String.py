name = 'Maulana Ali'
message = "maulana Ali belajar bahasa python di Belajarpython"
print ("name[0]: ", name[0])
print ("message[1:4]: ", message[1:4])