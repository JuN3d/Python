message = 'Hello world!'
print("Update String :- ", message[:6] + 'Python')