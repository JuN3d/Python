# Update Dictionary Python

dict = {'Name' : 'Maulana Ali Hanafiah', 'Age' : 21, 'Class' : 'Last'}

# Mengubah Dictionary
dict['Age'] = 22;
dict['School'] = "Al-Basyariyah Islamic Boarding School"

print("dict['Age']: ", dict['Age'])
print("dict['School']: ", dict['School'])