# Cara membuat nilai dictionary pad Python

dict = {'Name' : 'Maulana Ali Hanafiah', 'Age' : 21, 'Class' : 'Last'}

print("dict['Name']: ", dict['Name'])
print("dict['Age']: ", dict['Age'])