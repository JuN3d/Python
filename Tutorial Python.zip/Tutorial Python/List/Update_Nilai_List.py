list = ['Fisika', 'Kimia', 1995, 2021]
print("Nilai pada Index 2 adalah : ", list[2])

list[2] = 2001
print("Nilai pada Index 2 adalah : ", list[2])