# Contoh cara Menghapus nilai list

list = ['fisika', 'Kimia', 1999, 2021]
print(list)
del list[2]
print("Setelah dihapus nilai pada index 2 :", list)