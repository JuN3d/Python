# Contoh Sederhana membuat list pada bahas Pemrograman Python

list1 = ['Kimia', 'Fisika', 1999, 1997, 1987]
list2 = [1, 2, 3, 4, 5]
list3 = ["a", "b", "c", "d", "e"]

print(list1)
print(list2)
print(list3)