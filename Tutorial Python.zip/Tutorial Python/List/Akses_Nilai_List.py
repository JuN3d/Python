# Cara mengakses nilai List

list1 = ['Kimia', 'Fisika', 1999, 1997, 1987]
list2 = [1, 2, 3, 4, 5]

print("list1[0] : ", list1[0])
print("list2[1:5] : ", list2[1:5])