# Kondisi If Else adalah jika kondisi bernilai TRUE maka akan di eksekusi pada If, Tetapi jika FALSE 
# maka akan di eksekusi pada else

nilai = 3

# Jika pernyataan If bernilai TRUE maka If akan dieksekusi, tetapi jika FALSE maka Else yang akan dieksekusi

if(nilai > 7):
    print("Selamat Anda Lulus")
else:
    print("Maaf Anda Tidak Lulus")