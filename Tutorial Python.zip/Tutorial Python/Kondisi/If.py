#Kondisi if adalah kondisi yang akan dieksekusi oleh program jika bernilai benar atau TRUE

nilai = 9

#jika kondisi benar/TRUE maka program akan mengeksekusi perintah dibawahnya

if(nilai > 7):
    print("Sembilan lebih besar dari tujuh")    # Kondisi Benar, Dieksekusi

#jika kondisi salah/FALSE maka program tidak akan mengeksekusi perintah dibawahnya

if(nilai > 10):
    print("Sembilan Lebih Besar Dari Angka Sepuluh")   # Kondisi Salah, Tidak Dieksekusi