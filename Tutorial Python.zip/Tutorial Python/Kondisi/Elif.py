#Contoh Penggunaan Kondisi elif

hari_ini = "Minggu"

if(hari_ini == "Senin"):
    print("Saya akan Kuliah")
if(hari_ini == "Selasa"):
    print("Saya akan Kuliah")
if(hari_ini == "Rabu"):
    print("Saya akan Kuliah")
if(hari_ini == "Kamis"):
    print("Saya akan Kuliah")
if(hari_ini == "Jum'at"):
    print("Saya akan Kuliah")
if(hari_ini == "Sabtu"):
    print("Saya akan Kuliah")
if(hari_ini == "Minggu"):
    print("Saya akan Libur")