# Contoh Sederhana mengakses Tuple Python

tup1 = ('Fisika', 'Kimia', 1999, 2021)
tup2 = (1, 2, 3, 4, 5)

print("tup1[0]", tup1[0])
print("tup2[1:5]", tup2[1:5])