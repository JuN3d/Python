# Contoh Sederhana membuat Tuple Python

tup1 = ('Fisika', 'Kimia', 1999, 2021)
tup2 = (1, 2, 3, 4, 5)
tup3 = "a", "b" , "c", "d", "e"

print(tup1)
print(tup2)
print(tup3)