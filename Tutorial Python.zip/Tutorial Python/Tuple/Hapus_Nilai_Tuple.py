tup = ('Fisika', 'Kimia', 1999, 2021)
print(tup)

# Hapus Tuple dengan statement del
del tup

# lalu buat kembali tuple yang baru dengan elemen yang diinginkan

tup = ('Pemgrograman', 'Hacking', 2000, 2021)
print("Setelah menghapus Tuple : ", tup)